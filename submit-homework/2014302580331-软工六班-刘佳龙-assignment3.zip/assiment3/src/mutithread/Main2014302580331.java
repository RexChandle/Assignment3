package mutithread;

import java.io.IOException;
import java.sql.SQLException;

public class Main2014302580331 {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Mession m = new Mession();
		long begin2 = System.currentTimeMillis();
		m.runBySinglethread();
		System.out.print("���߳�����ʱ�䣺" );
		System.out.println(System.currentTimeMillis() - begin2);
		long begin1 = System.currentTimeMillis();
		m.runByMultithread();
		while(true){
			if(Thread.activeCount() == 1){
				break;
			}
		}
		long end1 = System.currentTimeMillis();
		System.out.print("���߳�����ʱ�䣺" );
		System.out.println(end1 - begin1);
	}
}