package mutithread;
import java.io.File;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GetHTML {
	public final static int num=99;
	public static int getTeacherNumber(){return num;};
	private String name;
	private String url;
	
	public GetHTML(){
		name = null;
		url = null;
	}
	public GetHTML(String n,String u){
		name = "./HTMLfiles/"+n;
		url = u;
	}
	 public void setURL(String u){
		 url = u;
	 }

	 public void setHtmlName(String sh){
		 name = "./crawlfiles/" + sh;
	 }
	public boolean getHtml(){
		HttpRequest receive = HttpRequest.get(url);
		if(receive.ok()){
			receive.receive(new File(name));
			return true;
		}
		else
			return false;
	}
	public LinkedList<String> getURLsFromTeachers(File input) throws IOException
	 {
		LinkedList<String> urls = new LinkedList<String>();
		Document doc = Jsoup.parse(input,"UTF-8");
		Elements uls = doc.select("div.page-content");
		Elements ed =  uls.select("a");
		for(Element e:ed){
			urls.add(("http://staff.whu.edu.cn/"+ e.attr("href")).replaceAll(" ","%20"));
		}
		return urls;		 
	 }
	
	 public String[] getDataFromATeacher(File input) throws IOException
	 {
		String[] inf = new String[4];
		inf[3] = "";
		                                                  
		Document doc1 = Jsoup.parse(input, "UTF-8");                                                     
		Elements imfo1 = doc1.select("div.col-md-10");
		Elements imfo2 = doc1.select("div.szll_wz");                                        

		inf[0] = imfo1.select("h3").text();
		inf[1] = "";
		
		//�绰����ƥ��
		Pattern p_tel = Pattern.compile("1[358][\\d]{9}");
		Matcher m_tel = p_tel.matcher(imfo1.text());
		if(m_tel.find())
		{
			inf[1] = m_tel.group(0);
		}
		
		//����ƥ��
		String[] s = imfo1.text().split(" ");
		for(String s1:s)
		{
			Pattern p_mail = Pattern.compile("^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$");
			Matcher m_mail = p_mail.matcher(s1);
			if(m_mail.find())
			{
				inf[2] = m_mail.group(0);
			}
		}
		inf[3] = imfo2.text();
		return inf;
	}
	 public void setDataBase(String[] teacher) throws ClassNotFoundException{
		 Connection conn = null;
		 String sql;
		 String url = "jdbc:mysql://127.0.0.1:3306/MySQL?" + "user=root&password=qwemnb5885860&useUnicode=true&characterEncoding=UTF8";

		 Class.forName("com.mysql.jdbc.Driver");
		 try {
			conn = DriverManager.getConnection(url);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 if(teacher[3].length() > 500){
			 teacher[3] = "data too long!";
		 }
         sql = "insert into teacher(name,tel,mail,sit) values('" + teacher[0]+"','"+teacher[1]+"','"+teacher[2]+"','"+teacher[3]+"')";
         try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	         
	 }


}

	 

