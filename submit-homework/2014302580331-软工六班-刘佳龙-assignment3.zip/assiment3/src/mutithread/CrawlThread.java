package mutithread;

import java.io.File;
import java.io.IOException;

public class CrawlThread implements Runnable{
	String url;
	String name;
	public CrawlThread(String s,String name){
		url = s;
		this.name = name;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		//��ȡ��ʦ��html
		GetHTML getteacherData = new GetHTML();
		getteacherData.setURL(url);
		getteacherData.setHtmlName(name);
		getteacherData.getHtml();
		
		//����html�ļ�
		try {
			getteacherData.setDataBase(getteacherData.getDataFromATeacher(new File("./crawlfiles/"+name)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
