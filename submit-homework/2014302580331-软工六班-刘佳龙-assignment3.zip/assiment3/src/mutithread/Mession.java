package mutithread;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;

public class Mession{

	public void runByMultithread() throws IOException{
		LinkedList<String> urls = new LinkedList<String>();
		GetHTML teachers = new GetHTML();
		teachers.setURL("http://staff.whu.edu.cn/");
		teachers.setHtmlName("teachers.html");
		teachers.getHtml();
		urls = teachers.getURLsFromTeachers(new File("./crawlfiles/teachers.html"));
		
		Iterator it = urls.listIterator();
		int num = 0;
		while(it.hasNext()){
			String s = (String) it.next();
			new Thread(new CrawlThread(s,"teacher"+num)).start();
			num++;
		}
	}
	
	public void runBySinglethread() throws IOException, ClassNotFoundException{
		LinkedList<String> urls = new LinkedList<String>();
		GetHTML teachers = new GetHTML();
		teachers.setURL("http://staff.whu.edu.cn/");
		teachers.setHtmlName("teachers.html");
		teachers.getHtml();
		urls = teachers.getURLsFromTeachers(new File("./crawlfiles/teachers.html"));
		
		Iterator it = urls.listIterator();
		int num = 0;
		while(it.hasNext()){
			String s =(String) it.next();
			teachers.setHtmlName("teacher"+num+".html");
			teachers.setURL(s);
			teachers.getHtml();
			teachers.setDataBase(teachers.getDataFromATeacher(new File("./crawlfiles/teacher" + num +".html")));
			num++;
		}
	}
	
}
		



